#include <mpi.h>
#include <stdio.h>
#include <omp.h>
#include <stdlib.h>
#include "myProto.h"

#define MPI_THREAD_COUNT 4

int* readFile(FILE* file, int* size){
	int i;
	int* data;
	FILE* f = fopen(FILE_NAME,"r");
	if(!f)
	{
		printf("Could not open file %s", FILE_NAME);
		exit(0);
	}
	
	fscanf(f,"%d\n",size);
	data = (int*)malloc(sizeof(int)*(*size));
	
	for(i=0; i<(*size); i++)
		fscanf(f,"%d\n",&data[i]);
	
	fclose(f);
	return data;
}

int main(int argc, char *argv[]) {
    int inputSize, currentProcess, processCount;
    int *data;
    MPI_Status mpiStatus;
	
	// Each thread gets INPUT_MAX_VALUE entries in the array, one for each possible input value
	int openMPHist[MPI_THREAD_COUNT * INPUT_MAX_VALUE];
	int CUDAHist[INPUT_MAX_VALUE * PART];
	
	int totalCount[INPUT_MAX_VALUE];
	int totalCountCUDA[INPUT_MAX_VALUE];

    MPI_Init(&argc, &argv);
    MPI_Comm_size(MPI_COMM_WORLD, &processCount);
	
    MPI_Comm_rank(MPI_COMM_WORLD, &currentProcess);
    
    //Divide the tasks between 2 processes
    if (currentProcess == MASTER) {
		FILE* file = fopen("data.txt","r");
		if(!file)
		{
			printf("Could not open data.txt\n");
			exit(0);
		}

		data = readDataFile(file, &inputSize);
		MPI_Send(&inputSize,1,MPI_INT,1,0,MPI_COMM_WORLD); //Sending the inputSize to process 1
		MPI_Send(data+inputSize/2,inputSize/2,MPI_INT,1,0,MPI_COMM_WORLD); //Sending half of the data to process 1
    }
	
    else if (currentProcess == 1) {
	MPI_Recv(&inputSize,1,MPI_INT,0,0,MPI_COMM_WORLD,&mpiStatus); //get the inputSize
	data = (int*)malloc(sizeof(int)*(inputSize/2));
	MPI_Recv(data,inputSize/2,MPI_INT,0,0,MPI_COMM_WORLD,&mpiStatus); //get half of the data
    }

    //Reset arrays
	for (int i = 0; i < INPUT_MAX_VALUE; i++) {
		totalCount[i] = 0;
	}
    
	for (int i = 0; i < MPI_THREAD_COUNT * INPUT_MAX_VALUE; i++) {
		openMPHist[i] = 0;
	}

	for (int i = 0; i < INPUT_MAX_VALUE * PART; i++) {
		CUDAHist[i] = 0;
	}
	
	//On each process (0 and 1) - perform the first half of the task via OpenMP
	countDigitViaOpenMP(openMPHist, data);
	uniteSameDigitsViaOpenMP(MPI_THREAD_COUNT, openMPHist, totalCount);
	
	
	//On each process (0 and 1) - perform the second half of ths task via CUDA
	if (computeOnGPU(data + PART, totalCount, CUDAHist, PART,INPUT_MAX_VALUE, INPUT_MAX_VALUE * PART) != 0)
		MPI_Abort(MPI_COMM_WORLD, __LINE__);
	

	if (currentProcess == 1) {
		MPI_Send(&totalCount[0], INPUT_MAX_VALUE, MPI_INT, 0, 0, MPI_COMM_WORLD); //send the result from process 1 to process 0
	} else if (currentProcess == MASTER) {
		MPI_Recv(&totalCountCUDA[0], INPUT_MAX_VALUE, MPI_INT, 1, 0, MPI_COMM_WORLD, &mpiStatus); //insert the result from process 1 into totalCountCUDA

		//collect the totalCount from process 1
		for (int i = 0; i < INPUT_MAX_VALUE; i++) {
			totalCount[i] += totalCountCUDA[i];
		}
		
		printf("The result of histogram: \n\n");
		for (int i = 0; i < INPUT_MAX_VALUE; i++) {
			printf("%d: %d\n", i, totalCount[i]);
		}
	}

    MPI_Finalize();
    return 0;
}


