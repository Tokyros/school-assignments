#pragma once

#define INPUT_MAX_VALUE 256

int computeOnGPU(int *data, int *totalCount, int *countFromCUDA, int numPartElements, int rangeNumbers, int numberMultThreads);
